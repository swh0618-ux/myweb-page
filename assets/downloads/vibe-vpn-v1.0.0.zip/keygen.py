#!/usr/bin/env python3
"""
Vibe VPN - 256-bit Pre-Shared Key Generator
"""
import secrets

def main():
    key = secrets.token_hex(32)
    print("=" * 60)
    print("🔑 Vibe VPN 보안 대칭키 (Pre-Shared Key) 생성 완료:")
    print(f"    {key}")
    print("=" * 60)
    print("👉 이 키를 config.json의 'pre_shared_key' 항목에 복사하여")
    print("   클라이언트와 서버 양쪽에 동일하게 설정하세요.")

if __name__ == "__main__":
    main()
