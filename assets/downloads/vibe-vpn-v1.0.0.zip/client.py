#!/usr/bin/env python3
"""
Vibe VPN - Asynchronous UDP Client Tunnel
"""
import os
import sys
import json
import asyncio
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305

MAGIC = b"VIBE"

class VibeClientProtocol(asyncio.DatagramProtocol):
    def __init__(self, key_bytes: bytes, server_addr: tuple):
        self.cipher = ChaCha20Poly1305(key_bytes)
        self.server_addr = server_addr
        self.transport = None

    def connection_made(self, transport):
        self.transport = transport
        print(f"[Client] UDP 터널이 시작되었습니다. 게이트웨이: {self.server_addr[0]}:{self.server_addr[1]}")
        asyncio.create_task(self.ping_loop())

    def datagram_received(self, data: bytes, addr):
        if len(data) < 32 or not data.startswith(MAGIC):
            return
        nonce = data[4:16]
        ciphertext = data[16:]
        try:
            plaintext = self.cipher.decrypt(nonce, ciphertext, None)
            print(f"[Client] 복호화 패킷 수신 ({len(plaintext)} bytes) from {addr}")
        except Exception as e:
            print(f"[Client] 복호화 실패: {e}")

    def send_packet(self, payload: bytes):
        nonce = os.urandom(12)
        encrypted = self.cipher.encrypt(nonce, payload, None)
        wire_packet = MAGIC + nonce + encrypted
        self.transport.sendto(wire_packet, self.server_addr)

    async def ping_loop(self):
        """연결 유지 및 테스트용 핑 패킷 루프"""
        count = 0
        while True:
            await asyncio.sleep(5)
            count += 1
            msg = f"VIBE_PING #{count}".encode("utf-8")
            self.send_packet(msg)
            print(f"[Client] 핑 전송 -> {self.server_addr}")

async def main():
    config_path = os.path.join(os.path.dirname(__file__), "config.json")
    if not os.path.exists(config_path):
        print("[!] config.json 파일이 존재하지 않습니다.")
        sys.exit(1)

    with open(config_path, "r", encoding="utf-8") as f:
        config = json.load(f)

    key_bytes = bytes.fromhex(config["pre_shared_key"])
    server_addr = (config["server_host"], config["server_port"])

    loop = asyncio.get_running_loop()
    transport, protocol = await loop.create_datagram_endpoint(
        lambda: VibeClientProtocol(key_bytes, server_addr),
        local_addr=("0.0.0.0", 0)
    )

    try:
        while True:
            await asyncio.sleep(3600)
    finally:
        transport.close()

if __name__ == "__main__":
    asyncio.run(main())
