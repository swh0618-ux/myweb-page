# 🛡️ Python Vibe VPN v1.0.0

Python 3.11+ 비동기 I/O와 ChaCha20-Poly1305 기반의 초경량 암호화 VPN 터널 배포 패키지입니다.

---

## 🚀 빠른 시작 가이드 (Quick Start)

### 1. 의존성 패키지 설치
```bash
pip install -r requirements.txt
```

### 2. 보안 대칭키(PSK) 생성
```bash
python keygen.py
```
* 출력된 64자리 Hex 키를 복사하여 `config.json`의 `pre_shared_key`에 설정합니다.

### 3. 서버 실행 (VPS 또는 호스트 머신)
```bash
python server.py
```

### 4. 클라이언트 실행 (로컬 PC)
`config.json`의 `server_host`에 서버 IP를 입력한 후 실행합니다:
```bash
python client.py
```

---

## 📁 패키지 파일 구성
* `client.py`: 비동기 UDP 클라이언트 터널링 스크립트
* `server.py`: 비동기 UDP 게이트웨이 서버 스크립트
* `keygen.py`: 암호화 대칭키(256-bit PSK) 자동 생성기
* `config.json`: 서버 주소, 포트, 키, MTU 설정 파일
* `requirements.txt`: 필수 파이썬 라이브러리 (`cryptography`)
