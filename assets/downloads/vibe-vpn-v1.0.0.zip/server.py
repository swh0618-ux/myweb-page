#!/usr/bin/env python3
"""
Vibe VPN - Asynchronous UDP Server Gateway
"""
import os
import sys
import json
import asyncio
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305

MAGIC = b"VIBE"

class VibeServerProtocol(asyncio.DatagramProtocol):
    def __init__(self, key_bytes: bytes):
        self.cipher = ChaCha20Poly1305(key_bytes)
        self.transport = None

    def connection_made(self, transport):
        self.transport = transport
        sock = transport.get_extra_info("socket")
        print(f"[Server] Vibe VPN 게이트웨이가 대기 중입니다: {sock.getsockname()}")

    def datagram_received(self, data: bytes, addr):
        # 1. 헤더 유효성 검사
        if len(data) < 32 or not data.startswith(MAGIC):
            return  # 잘못된 패킷 무시

        nonce = data[4:16]
        ciphertext = data[16:]

        try:
            # 2. ChaCha20 복호화
            plaintext = self.cipher.decrypt(nonce, ciphertext, None)
            print(f"[Server] 수신 패킷 복호화 성공 ({len(plaintext)} bytes) from {addr}: {plaintext[:40]}")

            # 3. 에코/응답 패킷 전송 (테스트 및 연결 확인)
            reply_payload = b"ACK:" + plaintext
            reply_nonce = os.urandom(12)
            reply_encrypted = self.cipher.encrypt(reply_nonce, reply_payload, None)
            reply_packet = MAGIC + reply_nonce + reply_encrypted
            self.transport.sendto(reply_packet, addr)

        except Exception as e:
            print(f"[Server] 복호화 인증 실패: {e}")

async def main():
    config_path = os.path.join(os.path.dirname(__file__), "config.json")
    if not os.path.exists(config_path):
        print("[!] config.json 파일이 존재하지 않습니다.")
        sys.exit(1)

    with open(config_path, "r", encoding="utf-8") as f:
        config = json.load(f)

    key_bytes = bytes.fromhex(config["pre_shared_key"])
    listen_port = config["server_port"]

    loop = asyncio.get_running_loop()
    transport, protocol = await loop.create_datagram_endpoint(
        lambda: VibeServerProtocol(key_bytes),
        local_addr=("0.0.0.0", listen_port)
    )

    try:
        while True:
            await asyncio.sleep(3600)
    finally:
        transport.close()

if __name__ == "__main__":
    asyncio.run(main())
